﻿using FinalTaskWebApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FinalTaskWebApplication.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TerminalController : ControllerBase
    {
        private readonly AppDbContext _db = new AppDbContext();

        [HttpGet("books")]
        public ActionResult<List<Product>> GetAllBooks()
        {
            return _db.Products.FromSqlRaw(@"
        SELECT 
            Sku, 
            COALESCE(Title, '') AS Title, 
            COALESCE(Unit, '') AS Unit, 
            Price, 
            COALESCE(Author, '') AS Author, 
            COALESCE(Publisher, '') AS Publisher, 
            COALESCE(Category, '') AS Category, 
            Discount, 
            StockQuantity, 
            COALESCE(Description, '') AS Description, 
            COALESCE(ImageName, '') AS ImageName 
        FROM Products").ToList();
        }

        [HttpPost("login")]
        public ActionResult<User> Login(string username, string password)
        {
            // Читаем данные напрямую через чистый SQL, чтобы обойти проверку связей и RoleId
            var user = _db.Users.FromSqlRaw(@"
        SELECT 
            Username, 
            PasswordHash, 
            COALESCE(RoleName, 'Клиент') AS RoleName, 
            COALESCE(FullName, Username) AS FullName
        FROM Users 
        WHERE Username = {0} AND PasswordHash = {1}", username, password).AsNoTracking().FirstOrDefault();

            if (user == null)
            {
                return NotFound("Неверный логин или пароль");
            }

            return user;
        }

        [HttpPost("create-order")]
        public ActionResult CreateOrder([FromBody] Order NewOrder)
        {
            try
            {
                int maxId = _db.Orders.Any() ? _db.Orders.Max(o => o.OrderId) : 0;
                NewOrder.OrderId = maxId + 1;

                NewOrder.Status = "Новый";
                NewOrder.OrderDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                _db.Orders.Add(NewOrder);
                _db.SaveChanges();

                if (NewOrder.ItemsRaw != null)
                {
                    var skus = NewOrder.ItemsRaw.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (var sku in skus)
                    {
                        var cleanSku = sku.Trim();
                        var product = _db.Products.FirstOrDefault(p => p.Sku == cleanSku);

                        var detail = new OrderDetail
                        {
                            OrderId = NewOrder.OrderId,
                            ProductSku = cleanSku,
                            Quantity = 1,
                            PriceAtPurchase = product != null ? (product.Price != null ? double.Parse(product.Price) : 0) : 0
                        };
                        _db.OrderDetails.Add(detail);
                    }
                    _db.SaveChanges();
                }

                return Ok(new { orderId = NewOrder.OrderId });
            }
            catch (Exception ex)
            {
                return BadRequest("Ошибка создания заказа: " + ex.Message);
            }
        }
    }
}

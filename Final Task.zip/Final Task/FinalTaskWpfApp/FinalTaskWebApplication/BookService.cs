﻿using Microsoft.EntityFrameworkCore;
using FinalTaskWebApplication.Models;

namespace FinalTaskWebApplication
{
    public class BookService
    {
        private readonly HttpClient _client = new HttpClient { BaseAddress = new Uri("https://localhost:7234/") };

        public List<Product> GetAllBooks()
        {
            var response = _client.GetAsync("api/terminal/books").Result;
            return response.IsSuccessStatusCode ? response.Content.ReadFromJsonAsync<List<Product>>().Result : new List<Product>();
        }

        public User Login(string login, string password)
        {
            var response = _client.PostAsJsonAsync($"api/terminal/login?username={login}&password={password}", "").Result;
            return response.IsSuccessStatusCode ? response.Content.ReadFromJsonAsync<User>().Result : null;
        }

        public void CreateOrder(int? userId, List<OrderDetail> items)
        {
            var newOrder = new Order
            {
                UserId = userId,
                OrderDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                Status = "Новый",
                Details = items
            };

            var response = _client.PostAsJsonAsync("api/terminal/order", newOrder).Result;
        }
    }
}

using FinalTaskWebApplication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace FinalTaskWebApplication.Pages
{
    public class IndexModel : PageModel
    {
        private readonly AppDbContext _db = new AppDbContext();

        public string CurrentUserRole { get; set; } = "";
        public string CurrentUserFullName { get; set; } = "";

        public List<Product> Books { get; set; }
        public List<string> Publishers { get; set; }
        public int TotalCount { get; set; }

        [BindProperty(SupportsGet = true)] public string Search { get; set; }
        [BindProperty(SupportsGet = true)] public string Publisher { get; set; }
        [BindProperty(SupportsGet = true)] public double? MinPrice { get; set; }
        [BindProperty(SupportsGet = true)] public double? MaxPrice { get; set; }
        [BindProperty(SupportsGet = true)] public int? Sort { get; set; }

        public void OnGet()
        {
            var allBooks = GetBaseData();
            TotalCount = allBooks.Count;
            Publishers = allBooks.Where(b => !string.IsNullOrEmpty(b.Publisher)).Select(b => b.Publisher).Distinct().OrderBy(p => p).ToList();
            Books = ApplyFiltering(allBooks);
        }

        public IActionResult OnGetPartial(string search, string publisher, double? minPrice, double? maxPrice, int? sort)
        {
            Search = search; Publisher = publisher; MinPrice = minPrice; MaxPrice = maxPrice; Sort = sort;
            var allBooks = GetBaseData();
            var filtered = ApplyFiltering(allBooks);
            return new JsonResult(new { books = filtered, count = filtered.Count, total = allBooks.Count });
        }


        private List<Product> GetBaseData()
        {
            return _db.Products.FromSqlRaw(@"
                SELECT Sku, COALESCE(Title, '') AS Title, COALESCE(Unit, '') AS Unit, Price, 
                       COALESCE(Author, '') AS Author, COALESCE(Publisher, '') AS Publisher, 
                       COALESCE(Category, '') AS Category, Discount, StockQuantity, 
                       COALESCE(Description, '') AS Description, COALESCE(ImageName, '') AS ImageName 
                FROM Products").AsNoTracking().ToList();
        }

        private List<Product> ApplyFiltering(List<Product> allBooks)
        {
            var filtered = allBooks.AsEnumerable();

            if (!string.IsNullOrEmpty(Search))
            {
                string searchLower = Search.Trim().ToLower();
                filtered = filtered.Where(b => b.Title != null && b.Title.ToLower().Contains(searchLower));
            }

            if (!string.IsNullOrEmpty(Publisher) && Publisher != "��� �������������")
            {
                filtered = filtered.Where(b => b.Publisher == Publisher);
            }

            if (MinPrice.HasValue) filtered = filtered.Where(b => double.TryParse(b.Price, out double p) && p >= MinPrice.Value);
            if (MaxPrice.HasValue) filtered = filtered.Where(b => double.TryParse(b.Price, out double p) && p <= MaxPrice.Value);

            if (Sort.HasValue && Sort.Value > 0)
            {
                switch (Sort.Value)
                {
                    case 1: filtered = filtered.OrderBy(b => double.TryParse(b.Price, out double p) ? p : 0); break;
                    case 2: filtered = filtered.OrderByDescending(b => double.TryParse(b.Price, out double p) ? p : 0); break;
                    case 3: filtered = filtered.OrderBy(b => b.Title); break;
                    case 4: filtered = filtered.OrderByDescending(b => b.Title); break;
                }
            }

            return filtered.ToList();
        }
    }
}

﻿using FinalTaskWebApplication.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalTaskWebApplication
{
    public class AppDbContext : DbContext
    {
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=|DataDirectory|books_terminal.db");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Product>(entity =>
            {
                entity.Property(e => e.Price).IsRequired(false);
                entity.Property(e => e.Discount).IsRequired(false);
                entity.Property(e => e.StockQuantity).IsRequired(false);
            });
        }
    }
}

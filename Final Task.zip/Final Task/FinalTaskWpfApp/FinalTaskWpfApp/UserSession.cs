﻿namespace FinalTaskWpfApp
{
    public static class UserSession
    {
        public static int CurrentUserId { get; set; } = -1;
        public static string CurrentUserFullName { get; set; } = "";
        public static string CurrentUserRole { get; set; } = "";
    }
}
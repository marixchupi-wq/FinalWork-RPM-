﻿using System.ComponentModel.DataAnnotations;

namespace FinalTaskWpfApp.Models
{
    public class Product
    {
        [Key]
        public string Sku { get; set; }
        public string Title { get; set; }
        public string Unit { get; set; }
        public string Price { get; set; }
        public string Author { get; set; }
        public string Publisher { get; set; }
        public string Category { get; set; }
        public string Discount { get; set; }
        public string StockQuantity { get; set; }
        public string Description { get; set; }
        public string ImageName { get; set; }

    }
}

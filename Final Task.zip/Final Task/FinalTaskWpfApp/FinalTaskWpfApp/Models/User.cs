﻿using System.ComponentModel.DataAnnotations;

namespace FinalTaskWpfApp.Models
{
    public class User
    {
        [Key]
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string RoleName { get; set; }
        public string FullName { get; set; }
    }
}

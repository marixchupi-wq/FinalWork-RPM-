﻿namespace FinalTaskWpfApp.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public int? UserId { get; set; }
        public string OrderDate { get; set; }
        public string Status { get; set; }

        public User User { get; set; }
        public List<OrderDetail> Details { get; set; } = new();
    }
}

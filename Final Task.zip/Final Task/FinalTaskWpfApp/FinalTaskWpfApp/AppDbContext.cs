﻿using FinalTaskWpfApp.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalTaskWpfApp
{
    public class AppDbContext : DbContext
    {
        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=C:\\Users\\Admin\\OneDrive\\Desktop\\books_terminal.db");
        }
    }
}

﻿using FinalTaskWpfApp.Models;
using System.Net.Http;
using System.Net.Http.Json;

namespace FinalTaskWpfApp
{
    public class BookService
    {
        private readonly HttpClient _client = new HttpClient { BaseAddress = new Uri("https://localhost:7273/") };

        public List<Product> GetAllBooks()
        {
            var response = _client.GetAsync("api/terminal/books").Result;
            if (response.IsSuccessStatusCode)
            {
                return response.Content.ReadFromJsonAsync<List<Product>>().Result;
            }
            return new List<Product>();
        }

        public User Login(string login, string password)
        {
            var response = _client.PostAsJsonAsync($"api/terminal/login?username={login}&password={password}", "").Result;
            if (response.IsSuccessStatusCode)
            {
                return response.Content.ReadFromJsonAsync<User>().Result;
            }
            return null;
        }

        public void CreateOrder(int? userId, List<OrderDetail> items)
        {
            var newOrder = new Order
            {
                UserId = userId,
                OrderDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                Status = "Новый",
                Details = items
            };

            var response = _client.PostAsJsonAsync("api/terminal/order", newOrder).Result;
        }

        public bool SaveOrderToServer(string fullName, string itemsRaw, string pickupCode)
        {
            try
            {
                var response = _client.PostAsJsonAsync("api/terminal/create-order", new
                {
                    FullName = string.IsNullOrEmpty(fullName) ? null : fullName,
                    ItemsRaw = itemsRaw,
                    PickupCode = pickupCode,
                    Status = "Новый"
                }).Result;

                return response.IsSuccessStatusCode;
            }
            catch
            {
                return false;
            }
        }
    }
}

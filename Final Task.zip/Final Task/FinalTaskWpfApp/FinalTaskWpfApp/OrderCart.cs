﻿using FinalTaskWpfApp.Models;

namespace FinalTaskWpfApp
{
    public class CartItem
    {
        public Product Product { get; set; }
        public int Quantity { get; set; }
    }

    public static class OrderCart
    {
        public static List<CartItem> Items { get; set; } = new List<CartItem>();

        public static void AddProduct(Product product)
        {
            var existingItem = Items.Find(i => i.Product.Sku == product.Sku);

            if (existingItem != null)
            {
                existingItem.Quantity++;
            }
            else
            {
                Items.Add(new CartItem { Product = product, Quantity = 1 });
            }
        }
    }
}

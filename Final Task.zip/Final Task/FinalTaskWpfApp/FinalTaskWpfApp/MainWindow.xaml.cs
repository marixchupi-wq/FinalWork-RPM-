﻿using FinalTaskWpfApp.Models;
using System.Windows;
using System.Windows.Controls;

namespace FinalTaskWpfApp
{
    public partial class MainWindow : Window
    {
        private readonly BookService _bookService = new BookService();
        private List<Product> _allBooks = new List<Product>();

        public MainWindow()
        {
            InitializeComponent();
            SortComboBox.SelectedIndex = 0;
            LoadData();
            UpdateAuthUI();
        }

        private void LoadData()
        {
            try
            {
                _allBooks = _bookService.GetAllBooks();

                var publishers = _allBooks
                    .Where(b => !string.IsNullOrEmpty(b.Publisher))
                    .Select(b => b.Publisher)
                    .Distinct()
                    .OrderBy(p => p)
                    .ToList();

                publishers.Insert(0, "Все производители");
                PublisherComboBox.ItemsSource = publishers;
                PublisherComboBox.SelectedIndex = 0;

                ApplyFilters();
            }
            catch
            {
                MessageBox.Show("Ошибка подключения к серверу API!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateAuthUI()
        {
            string role = UserSession.CurrentUserRole;
            string fullName = UserSession.CurrentUserFullName;

            if (!string.IsNullOrEmpty(role))
            {
                UserFullNameTextBlock.Text = $"{fullName} ({role})";
                LoginMenuButton.Visibility = Visibility.Collapsed;
                LogoutMenuButton.Visibility = Visibility.Visible;

                if (role == "Администратор" || role == "Менеджер")
                {
                    OrdersManagerButton.Visibility = Visibility.Visible;
                }
                else
                {
                    OrdersManagerButton.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                UserFullNameTextBlock.Text = "Гость";
                LoginMenuButton.Visibility = Visibility.Visible;
                LogoutMenuButton.Visibility = Visibility.Collapsed;
                OrdersManagerButton.Visibility = Visibility.Collapsed;
            }
            UpdateCartButtonVisibility();
        }

        private void UpdateCartButtonVisibility()
        {
            if (OrderCart.Items.Count > 0)
            {
                ViewOrderButton.Visibility = Visibility.Visible;
            }
            else
            {
                ViewOrderButton.Visibility = Visibility.Collapsed;
            }
        }

        private void OrderButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null && button.Tag != null)
            {
                string bookSku = button.Tag.ToString();

                var selectedBook = _allBooks.FirstOrDefault(b => b.Sku == bookSku);
                if (selectedBook != null)
                {
                    OrderCart.AddProduct(selectedBook);

                    UpdateCartButtonVisibility();

                    MessageBox.Show($"Книга «{selectedBook.Title}» добавлена в текущий заказ!", "Корзина терминала", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
        }

        private void ViewOrderButton_Click(object sender, RoutedEventArgs e)
        {
            OrderWindow orderWin = new OrderWindow();
            orderWin.Owner = this;

            orderWin.ShowDialog();
            UpdateCartButtonVisibility();
        }

        private void LoginMenuButton_Click(object sender, RoutedEventArgs e)
        {
            LoginWindow loginWin = new LoginWindow();
            loginWin.Owner = this;
            if (loginWin.ShowDialog() == true)
            {
                UpdateAuthUI();
            }
        }

        private void LogoutMenuButton_Click(object sender, RoutedEventArgs e)
        {
            UserSession.CurrentUserId = -1;
            UserSession.CurrentUserFullName = "";
            UserSession.CurrentUserRole = "";

            UpdateAuthUI();
            MessageBox.Show("Вы вышли из учетной записи.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void OrdersManagerButton_Click(object sender, RoutedEventArgs e)
        {
            OrderWindow orderWin = new OrderWindow();
            orderWin.Owner = this;
            orderWin.ShowDialog();
            UpdateCartButtonVisibility();
        }


        private void FilterChanged(object sender, EventArgs e)
        {
            if (_allBooks == null) return;
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            var filtered = _allBooks.AsEnumerable();

            string searchText = SearchTextBox.Text.Trim().ToLower();
            if (!string.IsNullOrEmpty(searchText))
            {
                filtered = filtered.Where(b => b.Title != null && b.Title.ToLower().Contains(searchText));
            }

            if (PublisherComboBox.SelectedItem != null)
            {
                string selectedPublisher = PublisherComboBox.SelectedItem.ToString();
                if (selectedPublisher != "Все производители")
                {
                    filtered = filtered.Where(b => b.Publisher == selectedPublisher);
                }
            }

            if (double.TryParse(MinPriceTextBox.Text, out double minPrice))
            {
                filtered = filtered.Where(b => double.TryParse(b.Price, out double bookPrice) && bookPrice >= minPrice);
            }

            if (double.TryParse(MaxPriceTextBox.Text, out double maxPrice))
            {
                filtered = filtered.Where(b => double.TryParse(b.Price, out double bookPrice) && bookPrice <= maxPrice);
            }

            if (SortComboBox.SelectedIndex > 0)
            {
                switch (SortComboBox.SelectedIndex)
                {
                    case 1:
                        filtered = filtered.OrderBy(b => double.TryParse(b.Price, out double p) ? p : 0);
                        break;
                    case 2:
                        filtered = filtered.OrderByDescending(b => double.TryParse(b.Price, out double p) ? p : 0);
                        break;
                    case 3:
                        filtered = filtered.OrderBy(b => b.Title);
                        break;
                    case 4:
                        filtered = filtered.OrderByDescending(b => b.Title);
                        break;
                }
            }

            var resultList = filtered.ToList();
            BooksListBox.ItemsSource = resultList;
            CountTextBlock.Text = $"{resultList.Count} из {_allBooks.Count}";
        }
    }
}

﻿using System.Windows;
using System.Windows.Controls;

namespace FinalTaskWpfApp
{
    public partial class OrderWindow : Window
    {
        private readonly BookService _bookService = new BookService();

        public OrderWindow()
        {
            InitializeComponent();

            if (!string.IsNullOrEmpty(UserSession.CurrentUserFullName))
            {
                ClientNameTextBlock.Text = $"Клиент: {UserSession.CurrentUserFullName}";
            }
            else
            {
                ClientNameTextBlock.Text = "Клиент: Гость";
            }

            RefreshCart();
        }

        private void RefreshCart()
        {
            CartListBox.ItemsSource = null;
            CartListBox.ItemsSource = OrderCart.Items;

            double totalSum = 0;
            foreach (var item in OrderCart.Items)
            {
                if (double.TryParse(item.Product.Price, out double price))
                {
                    totalSum += price * item.Quantity;
                }
            }

            TotalSumTextBlock.Text = $"Итого: {totalSum} руб.";
        }

        private void CheckoutButton_Click(object sender, RoutedEventArgs e)
        {
            if (OrderCart.Items.Count == 0)
            {
                MessageBox.Show("Ваша корзина пуста!", "Предупреждение", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            Random rnd = new Random();
            string pickupCode = rnd.Next(100, 1000).ToString();

            var skusList = OrderCart.Items.Select(i => i.Product.Sku);
            string itemsRaw = string.Join(", ", skusList);
            string clientName = UserSession.CurrentUserFullName;

            bool isSaved = _bookService.SaveOrderToServer(clientName, itemsRaw, pickupCode);

            if (isSaved)
            {
                double totalSum = 0;
                System.Text.StringBuilder receiptItems = new System.Text.StringBuilder();

                foreach (var item in OrderCart.Items)
                {
                    if (double.TryParse(item.Product.Price, out double price))
                    {
                        totalSum += price * item.Quantity;
                    }
                    receiptItems.AppendLine($"- {item.Product.Title} (Артикул: {item.Product.Sku}) — {item.Quantity} шт. x {item.Product.Price} руб.");
                }

                string receiptText = $"       ТАЛОН ДЛЯ ПОЛУЧЕНИЯ      \n\n\n" +
                                     $"Дата заказа: {DateTime.Now:dd.MM.yyyy HH:mm:ss}\n" +
                                     $"Клиент: {(string.IsNullOrEmpty(clientName) ? "Гость" : clientName)}\n" +
                                     $"Статус: Новый\n\n\n" +
                                     $"СОСТАВ ЗАКАЗА:\n{receiptItems}\n" +
                                     $"ОБЩАЯ СУММА ЗАКАЗА: {totalSum} руб.\n\n" +
                                     $"КОД ДЛЯ ПОЛУЧЕНИЯ: {pickupCode}\n\n\n" +
                                     $"Для получения необходимо предъявить этот талон";

                Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
                saveFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt";
                saveFileDialog.FileName = $"Талон_Заказа_{DateTime.Now:yyyyMMdd_HHmmss}";
                saveFileDialog.Title = "Сохранение талона заказа";

                if (saveFileDialog.ShowDialog() == true)
                {
                    try
                    {
                        System.IO.File.WriteAllText(saveFileDialog.FileName, receiptText, System.Text.Encoding.UTF8);

                        MessageBox.Show($"Заказ успешно оформлен!\nТалон сохранен по пути:\n{saveFileDialog.FileName}\n\nКод получения: {pickupCode}",
                                        "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                        OrderCart.Items.Clear();
                        DialogResult = true;
                        Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Заказ сохранен в базу, но не удалось записать файл TXT: {ex.Message}", "Ошибка файла", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
            else
            {
                MessageBox.Show("Не удалось сохранить заказ на сервере!", "Ошибка сервера", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button != null && button.Tag != null)
            {
                string sku = button.Tag.ToString();
                var itemToRemove = OrderCart.Items.FirstOrDefault(i => i.Product.Sku == sku);
                if (itemToRemove != null)
                {
                    OrderCart.Items.Remove(itemToRemove);
                    RefreshCart();
                }
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
    }
}
